export interface day {
    date: string;
    day: string;
    startTime: string;
    endTime: string;
    forcastTime: string;
    place: string;
    address: string;
}