export interface Name{

    tourism: string;
    city: string;
    suburb: string;
    road: string;
    house_number: string;
    lat: string;
    lon: string;
    type: string;
  }