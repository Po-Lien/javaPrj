export interface headerData{
    Title: string;
    dateFrom: string;
    dateEnd: string;
}