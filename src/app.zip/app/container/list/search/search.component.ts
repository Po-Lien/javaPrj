import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  myControl = new FormControl();
  contry: string[] = ['台北市','新北市','宜蘭市','基隆市'];
  filteredOptions: Observable<string[]>;
  myControlPlace = new FormControl();
  place: string[] = ['台北市','新北市','宜蘭市','基隆市'];

  constructor() { }

  ngOnInit(){
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
    this.filteredOptions = this.myControlPlace.valueChanges.pipe(
      startWith(''),
      map(value => this._filterPlace(value))
    );
  }

  private _filter(value: string): string[]{
    const filterValue = value.toLowerCase();

    return this.contry.filter(contry => contry.toLowerCase().indexOf(filterValue) === 0);
  }

  private _filterPlace(value: string): string[]{
    const filterValue = value.toLowerCase();

    return this.place.filter(place => place.toLowerCase().indexOf(filterValue) === 0);
  }
}
